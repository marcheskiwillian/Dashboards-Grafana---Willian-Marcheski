# Nome do Dashboard

## Descrição

Explique de forma breve o objetivo do dashboard e quais informações ele monitora.

## Requisitos

- Grafana: informe a versão testada
- Fonte de dados: exemplo Zabbix, Prometheus, InfluxDB ou PostgreSQL
- Plugins: liste apenas se forem necessários

## Arquivos

- `dashboard.json`: arquivo para importação
- `preview.png`: imagem de prévia

## Importação

1. Acesse **Dashboards > New > Import**.
2. Envie o arquivo `dashboard.json`.
3. Escolha a fonte de dados.
4. Clique em **Import**.

## Variáveis e ajustes

Informe quais variáveis, grupos, hosts, itens ou consultas precisam ser adaptados.

## Observações

Inclua limitações, versões testadas e outras informações importantes.
