# Checklist antes de publicar um dashboard

- [ ] Removi senhas, tokens e chaves de API.
- [ ] Removi nomes e dados de clientes.
- [ ] Removi URLs internas sensíveis.
- [ ] Revisei os nomes das fontes de dados.
- [ ] Testei a importação do JSON em outro ambiente.
- [ ] Adicionei uma imagem de prévia.
- [ ] Informei a versão do Grafana.
- [ ] Listei os plugins necessários.
- [ ] Expliquei quais variáveis precisam ser adaptadas.
- [ ] Atualizei a tabela principal do README.
