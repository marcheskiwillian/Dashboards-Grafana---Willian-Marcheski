# Grafana Dashboards Community

Coleção gratuita de dashboards desenvolvidos para Grafana, com foco em monitoramento, redes, infraestrutura, NOC, provedores e observabilidade.

A proposta deste repositório é compartilhar conhecimento com a comunidade e disponibilizar modelos que possam ser estudados, utilizados e adaptados em diferentes ambientes.

## Dashboards disponíveis

Os dashboards serão adicionados gradualmente.

| Dashboard | Descrição | Prévia | Download |
|---|---|---|---|
| Em breve | Primeiro dashboard da coleção | Em breve | Em breve |

## Estrutura do repositório

```text
grafana-dashboards-community/
├── dashboards/   # Arquivos JSON exportados do Grafana
├── images/       # Imagens e prévias dos dashboards
├── docs/         # Documentações e instruções adicionais
├── LICENSE
└── README.md
```

## Como importar um dashboard

1. Baixe o arquivo `.json` desejado na pasta `dashboards`.
2. Acesse o Grafana.
3. Vá em **Dashboards > New > Import**.
4. Envie o arquivo JSON ou cole seu conteúdo.
5. Selecione a fonte de dados correspondente.
6. Clique em **Import**.

## Antes de utilizar

Alguns dashboards podem precisar de ajustes conforme o ambiente, como:

- Nome ou UID da fonte de dados;
- Consultas e itens do Zabbix;
- Variáveis;
- Grupos de hosts;
- Nomes de equipamentos e interfaces;
- Plugins utilizados;
- Versão do Grafana.

Consulte a documentação incluída na pasta de cada dashboard.

## Segurança

Os arquivos publicados neste repositório não devem conter:

- Senhas;
- Tokens;
- Chaves de API;
- Endereços internos sensíveis;
- Nomes de clientes;
- Informações confidenciais;
- Credenciais de fontes de dados.

Revise sempre o arquivo JSON antes de publicá-lo.

## Comunidade

Entre no grupo do Telegram para acompanhar novos dashboards, atualizações e conteúdos:

**Telegram:** COLOQUE_AQUI_O_LINK_DO_GRUPO

## Contribuições

Sugestões, correções e melhorias são bem-vindas. Você pode abrir uma Issue ou enviar um Pull Request.

## Licença

Este projeto está disponível sob a licença MIT. Consulte o arquivo [LICENSE](LICENSE).

---

Desenvolvido e compartilhado por [Willian Marcheski](https://github.com/marcheskiwillian).
